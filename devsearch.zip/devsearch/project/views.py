from django.shortcuts import render, redirect
# from django.http import HttpResponse
from .models import Project
from .forms import ProjectForm

# projectsList = [
#     {
#         'id': '1',
#         'title': 'Ecommerce Website',
#         'description': 'Fully functional ecommerce website'
#     },
#     {
#         'id': '2',
#         'title': 'Portfolio Website',
#         'description': 'A personal website to write articles and display work'
#     },
#     {
#         'id': '3',
#         'title': 'Social Network',
#         'description': 'An open source project built by the community'
#     }
# ]


# Create your views here.
def projects(requests):
    # return HttpResponse("Home Page")
    projects = Project.objects.all()
    return render(requests,"project/projects.html", {'projects':projects})

def project(requests, pk):
    # return HttpResponse(f"Page Number: {pk}")
    projectObj = Project.objects.get(id=pk)
    tags = projectObj.tag.all()
    return render(requests,"project/single-project.html", {'project':projectObj,'tags':tags})

def createProject(requests):
    form = ProjectForm()
    
    if requests.method == 'POST':
        form = ProjectForm(requests.POST,requests.FILES)
        if form.is_valid():
            form.save()
            return redirect("projects")
        
    context = {"form": form}
    return render(requests,"project/project-form.html",context)

def updateProject(requests,pk):
    projectobj = Project.objects.get(id=pk)
    form = ProjectForm(instance=projectobj)
    
    if requests.method == 'POST':
        form = ProjectForm(requests.POST,requests.FILES,instance=projectobj)
        if form.is_valid():
            form.save()
            return redirect("projects")
        
    context = {"form": form}
    return render(requests,"project/project-form.html",context)


def deleteProject(requests,pk):
    projectobj = Project.objects.get(id=pk)
    
    if requests.method == 'POST':
        projectobj.delete()
        return redirect("projects")
        
    context = {"object":projectobj}
    return render(requests,"project/delete-template.html",context)
        
    